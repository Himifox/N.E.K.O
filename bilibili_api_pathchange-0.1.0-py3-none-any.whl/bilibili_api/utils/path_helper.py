import os
from typing import Optional

_DATA_DIR: Optional[str] = None


def set_data_dir(custom_dir: str) -> None:
    """
    设置自定义数据目录路径。
    调用此函数后，所有数据文件将从指定目录读取。
    支持绝对路径和相对路径（相对于当前工作目录）。

    Args:
        custom_dir: 自定义数据目录的路径。
                    可以是绝对路径或相对路径。
                    例如: 
                    - 绝对路径: "E:/ECHO/config/bilibili_api_data"
                    - 相对路径: "config/bilibili_api_data"
    """
    global _DATA_DIR
    
    # 如果是相对路径，转换为绝对路径
    if not os.path.isabs(custom_dir):
        custom_dir = os.path.abspath(custom_dir)
    
    _DATA_DIR = custom_dir


def get_data_dir() -> Optional[str]:
    """
    获取当前设置的数据目录路径。

    Returns:
        自定义数据目录路径，如果未设置则返回 None。
    """
    return _DATA_DIR


def _get_package_data_dir() -> str:
    """
    获取包内置的数据目录路径。

    Returns:
        bilibili_api 包内的 data 目录路径。
    """
    return os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")


def get_api_file_path(field: str) -> str:
    """
    获取 API 文件的完整路径。

    Args:
        field: API 所属分类，即 data/api 下的文件名（不含后缀名）

    Returns:
        API 文件的完整路径。
    """
    if _DATA_DIR:
        return os.path.join(_DATA_DIR, "api", f"{field}.json")
    return os.path.join(_get_package_data_dir(), "api", f"{field}.json")


def get_data_file_path(filename: str) -> str:
    """
    获取数据文件的完整路径。

    Args:
        filename: 数据文件名（含后缀），例如 video_zone.json

    Returns:
        数据文件的完整路径。
    """
    if _DATA_DIR:
        return os.path.join(_DATA_DIR, filename)
    return os.path.join(_get_package_data_dir(), filename)


def resolve_data_path(relative_path: str) -> str:
    """
    解析数据文件的相对路径。
    如果设置了自定义数据目录，则相对于自定义目录；否则相对于包内置数据目录。

    Args:
        relative_path: 相对于数据目录的路径，例如 "api/video.json"

    Returns:
        完整的文件路径。
    """
    if _DATA_DIR:
        return os.path.join(_DATA_DIR, relative_path)
    return os.path.join(_get_package_data_dir(), relative_path)