article2dynamic: dict = {}
dynamic2article: dict = {}
article_is_note: dict = {}
dynamic_is_article: dict = {}
dynamic_is_opus: dict = {}
